package com.arcel.chef

import android.os.Bundle
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ComponentActivity.gameDataStore by preferencesDataStore(name = "arcel_game")

private val CUPS_KEY = intPreferencesKey("cups")
private val LEVEL_KEY = intPreferencesKey("level")

data class Dish(val name:String, val emoji:String, val ingredients:List<String>)

private val dishes = listOf(
    Dish("Arroz con pollo","🍗", listOf("Arroz","Pollo","Ajo","Cebolla","Ají")),
    Dish("Ropa vieja","🥩", listOf("Carne","Tomate","Cebolla","Ají")),
    Dish("Camarones al ajillo","🦐", listOf("Camarón","Ajo","Limón")),
    Dish("Pollo con papas","🥔", listOf("Pollo","Papa","Ajo","Cebolla")),
    Dish("Arroz marinero","🍤", listOf("Arroz","Camarón","Ají","Ajo"))
)
private val ingredients = listOf(
    "🍚" to "Arroz","🍗" to "Pollo","🧄" to "Ajo","🧅" to "Cebolla","🫑" to "Ají",
    "🍅" to "Tomate","🥩" to "Carne","🦐" to "Camarón","🥔" to "Papa","🍋" to "Limón"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            val prefs = gameDataStore.data.first()
            val savedCups = prefs[CUPS_KEY] ?: 0
            val savedLevel = prefs[LEVEL_KEY] ?: 1
            setContent { ArcelApp(savedCups, savedLevel, onSave = { cups, level ->
                lifecycleScope.launch { gameDataStore.edit { it[CUPS_KEY] = cups; it[LEVEL_KEY] = level } }
            }) }
        }
    }
}

@Composable
fun ArcelApp(initialCups:Int = 0, initialLevel:Int = 1, onSave:(Int,Int)->Unit = { _, _ -> }) {
    var screen by remember { mutableStateOf("home") }
    var cups by remember { mutableIntStateOf(initialCups) }
    var level by remember { mutableIntStateOf(initialLevel.coerceIn(1,10)) }
    var combo by remember { mutableIntStateOf(0) }
    var dishIndex by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var message by remember { mutableStateOf("¡Bienvenido, Chef Arcel!") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFFC94B4B),
            secondary = Color(0xFF4D9B6A),
            background = Color(0xFFFFF7E9)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFFFF7E9)) {
            when(screen) {
                "home" -> Home(
                    cups, level,
                    onPlay = { screen="game"; message="Selecciona los ingredientes del pedido." },
                    onLevels = { screen="levels" }
                )
                "levels" -> Levels(level, onBack={screen="home"}, onPick={
                    level=it; dishIndex=(it-1)%dishes.size; selected=emptySet(); onSave(cups, level)
                    screen="game"; message="¡Nuevo pedido!"
                })
                else -> Game(
                    cups, level, combo, dishes[dishIndex], selected, message,
                    onSelect={name -> selected = if(name in selected) selected-name else selected+name},
                    onCook={
                        val need=dishes[dishIndex].ingredients
                        val ok=selected.size==need.size && need.all{it in selected}
                        if(ok){
                            val reward=25+level*8+combo*5
                            cups+=reward; combo+=1
                            if(combo%3==0 && level<10) level+=1
                            onSave(cups, level)
                            message="🎉 ¡Excelente! +$reward CUP"
                            selected=emptySet()
                            dishIndex=(dishIndex+1)%dishes.size
                        } else {
                            combo=0
                            message="❌ Revisa los ingredientes del pedido."
                        }
                    },
                    onNext={
                        dishIndex=(dishIndex+1)%dishes.size
                        selected=emptySet()
                        message="🍽️ Nuevo pedido."
                    },
                    onBack={screen="home"}
                )
            }
        }
    }
}

@Composable
fun Home(cups:Int, level:Int, onPlay:()->Unit, onLevels:()->Unit) {
    val transition=rememberInfiniteTransition(label="chef")
    val scale by transition.animateFloat(0.96f,1.04f,infiniteRepeatable(tween(900),RepeatMode.Reverse),label="scale")
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("👨🏾‍🍳", fontSize=84.sp, modifier=Modifier.scale(scale))
        Text("ARCEL", fontSize=34.sp, fontWeight=FontWeight.Black)
        Text("Chef de Cocina", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("🪙 $cups CUP   •   ⭐ Nivel $level")
        Spacer(Modifier.height(24.dp))
        Button(onClick=onPlay, modifier=Modifier.fillMaxWidth().height(56.dp)) { Text("▶️  JUGAR", fontSize=18.sp) }
        OutlinedButton(onClick=onLevels, modifier=Modifier.fillMaxWidth().height(52.dp)) { Text("⭐  NIVELES") }
    }
}

@Composable
fun Levels(current:Int, onBack:()->Unit, onPick:(Int)->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("⭐ Selecciona un nivel", fontSize=26.sp, fontWeight=FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns=GridCells.Fixed(2), modifier=Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(10.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            items(10){ i ->
                val n=i+1; val enabled=n<=current
                Card(Modifier.fillMaxWidth().clickable(enabled=enabled){onPick(n)}) {
                    Box(Modifier.padding(20.dp), contentAlignment=Alignment.Center) {
                        Text("Nivel $n ${if(enabled) "🔓" else "🔒"}", fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
        OutlinedButton(onClick=onBack, modifier=Modifier.fillMaxWidth()) { Text("⬅️ Volver") }
    }
}

@Composable
fun Game(cups:Int, level:Int, combo:Int, dish:Dish, selected:Set<String>, message:String, onSelect:(String)->Unit, onCook:()->Unit, onNext:()->Unit, onBack:()->Unit) {
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text("🪙 $cups CUP", fontWeight=FontWeight.Bold)
            Text("⭐ Nivel $level", fontWeight=FontWeight.Bold)
            Text("🔥 $combo", fontWeight=FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("👩🏽‍🍳", fontSize=64.sp)
                Text("¡Chef Arcel! Tengo hambre 😋", fontWeight=FontWeight.Bold)
                Text("👨🏾‍🍳        🍳        🍽️", fontSize=46.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("📋 Pedido: ${dish.name}", fontSize=19.sp, fontWeight=FontWeight.Black)
                Text(dish.ingredients.joinToString("  •  "))
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(columns=GridCells.Fixed(5), modifier=Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(7.dp), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            itemsIndexed(ingredients){_, pair ->
                val isSelected=pair.second in selected
                Card(
                    Modifier.fillMaxWidth().clickable{onSelect(pair.second)},
                    colors=CardDefaults.cardColors(if(isSelected) Color(0xFFFFE5A7) else Color.White)
                ) {
                    Column(Modifier.padding(5.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        Text(pair.first, fontSize=25.sp)
                        Text(pair.second, fontSize=9.sp, fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
        Text(message, Modifier.fillMaxWidth().padding(7.dp), fontWeight=FontWeight.Bold)
        Button(onClick=onCook, modifier=Modifier.fillMaxWidth().height(52.dp)) { Text("🔥 COCINAR Y SERVIR") }
        OutlinedButton(onClick=onNext, modifier=Modifier.fillMaxWidth()) { Text("🍽️ Nuevo pedido") }
        TextButton(onClick=onBack, modifier=Modifier.fillMaxWidth()) { Text("⬅️ Salir") }
    }
}
