# Arcel: Chef de Cocina

Juego Android en Kotlin + Jetpack Compose.

## Incluye
- 10 niveles
- 5 recetas de inspiración cubana/latina
- pedidos e ingredientes
- combos y recompensas en CUP
- animación del chef
- progreso de CUP y nivel guardado localmente con DataStore
- icono de aplicación y recursos para Google Play
- configuración de release firmada mediante `keystore.properties`

## Compilación
Requiere Android Studio reciente, Android SDK Platform 35 y JDK 17+ compatible con el Android Gradle Plugin configurado.

1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice el proyecto.
3. Verifica que `keystore.properties` y `arcel-upload-key.jks` estén en la raíz.
4. Ejecuta **Build > Generate Signed Bundle / APK**.
5. Selecciona **Android App Bundle (AAB)** y la configuración `release`.
6. El resultado quedará normalmente en `app/build/outputs/bundle/release/`.

## Seguridad de firma
El archivo `arcel-upload-key.jks` es una clave de carga preparada para este proyecto. Para una publicación comercial real, es recomendable generar una nueva clave controlada por ti y guardar una copia segura fuera del proyecto. Nunca publiques el `.jks` ni `keystore.properties` en GitHub.

## Google Play
Usa `play_store_assets/play_store_listing.txt` para el texto de la ficha y los PNG incluidos para icono, gráfico destacado y capturas. Antes de publicar todavía tendrás que completar en Play Console los apartados de ficha, clasificación de contenido, seguridad de datos, política de privacidad si corresponde y pruebas requeridas por Google Play.
